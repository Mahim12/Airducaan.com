<!DOCTYPE HTML>
<html manifest="app_cache.appcache">

<head>
    <title>Ramroprice.com</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>

    </style>
</head>

<body style="background-color:#f9f9f9;">
    <nav class="navbar navbar-expand-lg sticky-top navbar-light bg-light">
        <a class="navbar-brand" href="home.php"><img src="assets/photos/products/Logo.png" alt="image" style="height:35px; object-fit:cover;" /></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarTogglerDemo02">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0 mr-lg-4">
                <li class="nav-item">
                    <a class="nav-link navs-link" href="#">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link navs-link" href="#">CONTACT</a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link navs-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        CATEGORIES
                    </a>
                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="#">Action</a>
                        <a class="dropdown-item" href="#">Another action</a>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                </li>
            </ul>
            <form class="form-inline my-2 my-lg-0" method="post" name="Form1" action="combine.php" target="_self">
                <input class="form-control mr-sm-2" name="name" type="search" placeholder="I want to compare. . ." required>
                <button class="btn btn-danger my-2 my-sm-0" type="submit" onsubmit="return OnButton1();">Search</button>
            </form>
        </div>
    </nav>
    <div class="page-footer hide-on-desktop-only">
        <div class="search-container">
            <form method="post" name="Form1" action="combine.php" target="_self">
                <input type="search" placeholder="Compare again. . ." name="name" required>
                <button onsubmit="return OnButton1();" type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
    </div>

    <div class="container mt-5 mt-lg-3">
        <div class="row">
            <div class='col-lg-12 col-md-12 col-12 mb-lg-4 mb-md-4 mb-2'>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">Search</li>
                        <li class="breadcrumb-item active" aria-current="page"><?php echo $_POST["name"]; ?></li>
                    </ol>
                </nav>
            </div>
        </div>

        <div class="row loader another">
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
            <div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'>
                <div class="loading">

                    <div class='img-container'>
                        <img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                    <div class='p-2'>
                        <img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' />
                    </div>
                </div>
            </div>
        </div>



        <div class="row">

            <?php

            include_once 'searchtrialmuncha.php';
            include_once 'searchtrialgajabko.php';
            include_once 'searchtrialsastodeal.php';
            include_once 'searchtrialthulo.php';

            $mainlink = array_merge($links1, $outputthulolinks, $links4, $gajabkolinks);
            $maindescription = array_merge($description1, $descriptionthulo, $description3,   $gajabkodescription);
            $mainimages = array_merge($images1, $images2, $images3, $gajabkoimagearray);
            $mainprices = array_merge($sastodealprices, $thuloprices, $pricesmuncha,  $last);
            $mainnames = array_merge($sastodealname, $thuloname1, $munchaname,  $gajabkoname);
            $last2 = array();
            foreach ($mainprices as $p) {
                array_push($last2, str_replace("8360", " ", $p));
            }
            $last3 = array();
            foreach ($last2 as $p) {
                if (preg_match_all("/[$\d,.]+/", $p, $numbers)) {
                    $lastnum = end($numbers[0]);
                    array_push($last3, $lastnum);
                }
            }
            $it = array_map(null, $mainimages, $last3, $maindescription, $mainlink, $mainnames);

            /* This is the filter code */
            $it = array_filter($it, function ($value) {
                return (bool) $value[0] && (bool) $value[1] && (bool) $value[2] && (bool) $value[3] && (bool) $value[4];
            });

            //shuffle($it);
            foreach ($it as $a) {
                echo "<div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'><a href = '" . $a[3] . "' class='card-link' target='_blank'><div class='card'><div class='img-container'><img class='card-img-top' src='" . $a[0] . "' alt='" . $a[2] . "' style = 'width:100%; height:100%; object-fit:contain;'/></div><div class='card-body'><h5 class='card-title'>$a[1]</h5> <p class='card-text'>$a[4]</p> <p class='card-text'>$a[2]</p><button class='btn btn-shop mt-lg-3 mt-md-3 mt-3'>SHOP</button></div></div></a></div>";
            }

            ?>



        </div>
    </div>

    <!-- Footer -->

    <div class="page-footer hide-on-mobile-and-tablet">
        <div class="search-container">
            <form method="post" name="Form1" action="combine.php" target="_self">
                <input type="search" placeholder="I want to compare. . ." name="name" required>
                <button onsubmit="return OnButton1();" type="submit"><i class="fa fa-search"></i></button>
            </form>
        </div>
    </div>
    <!-- Footer -->


    <div class="footer hide-on-desktop-only">
        <div class="row hide-on-desktop-only">

            <div class="col-lg-4 col-md-4 col-4 hide-on-desktop-only p-0">
                <a href="home.php" class="active"><img src="assets/photos/icons/home.png" style='width:100%; height:50px; object-fit:contain;' /></a>
            </div>

            <div class="col-lg-4 col-md-4 col-4 hide-on-desktop-only p-0 pt-1">
                <a href="about.php"><img src="assets/photos/icons/about.png" style='width:100%; height:45px; object-fit:contain;' /></a>
            </div>

            <div class="col-lg-4 col-md-4 col-4 hide-on-desktop-only p-0 pt-1">
                <a href="contact.php"><img src="assets/photos/icons/contact.png" alt="photo" style='width:100%; height:48px; object-fit:contain;' /></a>
            </div>

        </div>
    </div>


    <script>
        function OnButton1() {
            document.Form1.action = "searchtrialgajabko.php" // First target    
            document.Form1.submit(); // Submit the page

            document.Form1.action = "searchtrialthulo.php" // Second target   
            document.Form1.submit();

            document.Form1.action = "searchtrialmuncha.php" // third target   
            document.Form1.submit(); // Submit the page

            document.Form1.action = "searchtrialsastodeal.php" // third target   
            document.Form1.submit(); // Submit the page
            return true;
        }

        document.onreadystatechange = function() {
            if (document.readyState !== "complete") {
                document.querySelector(
                    ".loader").style.visibility = "visible";
            } else {
                document.querySelector(
                    ".loader").style.display = "none";

            }
        };




        $(document).ready(function() {
            $(".card-img-top").on("error", function() {
                $(this).attr('src', 'assets/photos/products/Logo.png');
            });
        });
        /*
        var counter = 0;
        $(window).scroll(function() {
            if ($(window).scrollTop() == $(document).height() - $(window).height() && counter < 2) {
                appendData();
            }
        });

        function appendData() {
            var html = '';
            for (i = 0; i < 16; i++) {
                html +=
                    "<div class='col-lg-3 col-md-6 col-12 mb-lg-4 mb-md-4 mb-2'><div class = 'loading'><div class='img-container'><img class='card-img-top' src='assets/photos/icons/load.gif' alt='loading. . .' style='width:100%; height:100%; object-fit:contain;' /> </div> <div class='p-2'><img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .'style='width:100%; height:100%; object-fit:contain;' /></div><div class='p-2'><img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .'style='width:100%; height:100%; object-fit:contain;' /></div><div class='p-2'><img class='card-img-top' src='assets/photos/icons/loadingdiv.png' alt='loading. . .'style='width:100%; height:100%; object-fit:contain;' /></div></div></div>";
            }
            $('.another').append(html);
            counter++;

        }
        */
    </script>
</body>

</html>